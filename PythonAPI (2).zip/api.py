from fastapi import FastAPI, HTTPException, Body
import numpy as np
from keras.models import Sequential
from fastapi.middleware.cors import CORSMiddleware
import logging
from sklearn.preprocessing import MinMaxScaler  # 新增scaler
from model.predictor import build_lstm_model
from pandas import DataFrame, concat

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="LSTM 预测服务")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化模型和scaler
n_timesteps = 3
model = build_lstm_model(n_timesteps)
scaler = MinMaxScaler(feature_range=(0, 1))  # 初始化标准化器
logger.info("LSTM模型和标准化器初始化完成")


def series_to_supervised(data, n_in=1, n_out=1, dropnan=True):
    """将时间序列转换为监督学习数据"""
    df = DataFrame(data)
    cols, names = list(), list()

    # 输入序列 (t-n, ... t-1)
    for i in range(n_in, 0, -1):
        cols.append(df.shift(i))
        names += [f'var(t-{i})' for _ in range(data.shape[1])]

    # 预测序列 (t, t+1, ... t+n)
    for i in range(0, n_out):
        cols.append(df.shift(-i))
        if i == 0:
            names += [f'var(t)' for _ in range(data.shape[1])]
        else:
            names += [f'var(t+{i})' for _ in range(data.shape[1])]

    agg = concat(cols, axis=1)
    agg.columns = names
    if dropnan:
        agg.dropna(inplace=True)
    return agg


@app.post("/predict", summary="生成LSTM预测结果")
async def predict(data: list = Body(...)):
    """
    接收数字列表，返回LSTM模型预测结果
    - 输入: 至少包含3个数字的列表
    - 输出: 预测结果列表
    """
    try:
        # 输入验证
        if not data or len(data) < n_timesteps:
            raise HTTPException(
                status_code=400,
                detail=f"输入数据长度至少需要{n_timesteps}个值"
            )

        # 数据转换与标准化
        sequence = np.array(data, dtype=np.float32).reshape(-1, 1)
        scaler.fit(sequence)  # 拟合标准化器
        scaled_sequence = scaler.transform(sequence)

        # 转换为监督学习格式
        supervised = series_to_supervised(scaled_sequence, n_timesteps, n_out=1)
        values = supervised.values

        if len(values) == 0:
            raise HTTPException(
                status_code=400,
                detail="输入数据无法转换为监督学习格式，请检查数据有效性"
            )

        # 模型预测
        X = values[:, :-1].reshape(-1, n_timesteps, 1)
        prediction = model.predict(X, verbose=0)
        prediction = scaler.inverse_transform(prediction)

        return {
            "prediction": prediction.flatten().tolist(),
            "input_length": len(data),
            "status": "success"
        }

    except Exception as e:
        logger.error(f"预测出错: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/test", summary="测试服务是否正常运行")
def test():
    return {
        "message": "后端服务正常",
        "status": "ok",
        "required_input_length": n_timesteps
    }


if __name__ == "__main__":
    import uvicorn

    logger.info("启动服务...")
    uvicorn.run(app, host="0.0.0.0", port=8000)