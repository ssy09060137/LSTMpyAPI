from pandas import DataFrame
from pandas import concat
from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import matplotlib.pyplot as plt

# 设置随机种子以保证结果可复现
np.random.seed(42)

# 创建更复杂的训练序列（包含线性趋势和周期性波动）
length = 100
x = np.linspace(0, 2*np.pi, length)
sequence = [i/float(length) + 0.1*np.sin(5*x[i]) for i in range(length)]
print(f"原始序列: {sequence[:10]}...")

# 数据归一化
scaler = MinMaxScaler(feature_range=(0, 1))
sequence = np.array(sequence).reshape(-1, 1)
scaled_sequence = scaler.fit_transform(sequence)
print(f"归一化后序列: {scaled_sequence[:10, 0]}...")

# 将序列转换为监督学习格式
def series_to_supervised(data, n_in=1, n_out=1, dropnan=True):
    df = DataFrame(data)
    cols, names = list(), list()
    # 输入序列 (t-n, ... t-1)
    for i in range(n_in, 0, -1):
        cols.append(df.shift(i))
        names += [f'var(t-{i})' for j in range(data.shape[1])]
    # 预测序列 (t, t+1, ... t+n)
    for i in range(0, n_out):
        cols.append(df.shift(-i))
        if i == 0:
            names += [f'var(t)' for j in range(data.shape[1])]
        else:
            names += [f'var(t+{i})' for j in range(data.shape[1])]
    # 合并
    agg = concat(cols, axis=1)
    agg.columns = names
    # 删除包含NaN的行
    if dropnan:
        agg.dropna(inplace=True)
    return agg

# 将时间序列转换为监督学习问题（使用3个时间步预测1个时间步）
n_timesteps = 3
supervised = series_to_supervised(scaled_sequence, n_timesteps, 1)
print(f"监督学习数据格式:\n{supervised.head()}")

# 准备训练数据
values = supervised.values
X, y = values[:, :-1], values[:, -1]
X = X.reshape(X.shape[0], n_timesteps, 1)  # [样本数, 时间步, 特征数]
print(f"输入数据形状: {X.shape}, 目标数据形状: {y.shape}")

# 定义改进的LSTM模型构建函数
def build_lstm_model(n_timesteps):
    """构建并返回LSTM模型"""
    model = Sequential()
    model.add(LSTM(100, return_sequences=True, input_shape=(n_timesteps, 1)))
    model.add(Dropout(0.2))
    model.add(LSTM(100))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    return model

# 构建模型
model = build_lstm_model(n_timesteps)

# 训练模型（增加训练轮次并添加早停机制）
from keras.callbacks import EarlyStopping, ModelCheckpoint
es = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)
history = model.fit(X, y, epochs=300, batch_size=32, verbose=1, validation_split=0.2, callbacks=[es])
print(f"训练完成，最终损失: {history.history['loss'][-1]:.6f}")

# 在训练集上评估模型
train_loss = model.evaluate(X, y, verbose=0)
print(f"训练集损失: {train_loss:.6f}")

# 预测训练集
train_predict = model.predict(X)
# 反归一化预测结果
train_predict = scaler.inverse_transform(train_predict)
y_actual = scaler.inverse_transform(y.reshape(-1, 1))

# 打印前10个预测结果与实际值对比
print("\n预测结果 vs 实际值:")
for i in range(min(10, len(train_predict))):
    print(f"预测: {train_predict[i, 0]:.4f}, 实际: {y_actual[i, 0]:.4f}, 误差: {abs(train_predict[i, 0]-y_actual[i, 0]):.4f}")

# 构建测试序列进行预测
test_length = 15
test_sequence = [(i+10)/float(test_length) + 0.1*np.sin(5*(i+10)/float(test_length)) for i in range(test_length)]
print(f"\n测试序列: {test_sequence}")

# 归一化测试序列
test_sequence = np.array(test_sequence).reshape(-1, 1)
scaled_test = scaler.transform(test_sequence)

# 转换为监督学习格式
test_supervised = series_to_supervised(scaled_test, n_timesteps, 1)
test_values = test_supervised.values
X_test, y_test = test_values[:, :-1], test_values[:, -1]
X_test = X_test.reshape(X_test.shape[0], n_timesteps, 1)

# 预测测试序列
test_predict = model.predict(X_test)
# 反归一化
test_predict = scaler.inverse_transform(test_predict)
y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))

# 打印测试预测结果
print("\n测试序列预测结果:")
print("预测序列:", [f"{x[0]:.4f}" for x in test_predict])
print("实际序列:", [f"{x[0]:.4f}" for x in y_test_actual])

# 可视化预测结果
plt.figure(figsize=(12, 6))
plt.plot(y_test_actual, 'b-', label='实际值')
plt.plot(test_predict, 'r--', label='预测值')
plt.title('LSTM预测结果')
plt.xlabel('时间步')
plt.ylabel('值')
plt.legend()
plt.grid(True)
plt.show()

# 保存模型和归一化器
def save_model_and_scaler(model, scaler, model_path="lstm_model.h5", scaler_path="scaler.pkl"):
    """保存模型和归一化器"""
    model.save(model_path)
    import pickle
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)

# 保存训练好的模型和归一化器（取消注释以执行）
# save_model_and_scaler(model, scaler)